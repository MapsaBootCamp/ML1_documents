﻿برآورد چگالی هسته چیست؟ برآورد چگالی هسته یک فرایند ریاضی برای یافتن تابع چگالی احتمال تخمین یک متغیر تصادفی است. برآورد سعی می کند بر اساس مجموعه داده های محدود ، ویژگی های یک جمعیت را استنباط کند.

ساده ترین برآورد چگالی غیر پارامتری یک هیستوگرام است. فضای نمونه را به تعدادی bin تقسیم کرده و تراکم در مرکز هر bin را با کسری از نقاط داده های آموزشی که در bin مربوط قرار می گیرند تقریب بزنید.

![C:\Users\1\Desktop\1 IPRB8dpn75jfYYBXqQyMsg.png](Aspose.Words.7989dca8-5af9-4a7f-884f-9dba146a44e3.001.png)

## `	`**Kernel density estimaiton** 
imporitng modules

import numpy as np

import matplotlib.pyplot as plt

from sklearn.datasets import load\_digits as ld

from sklearn.neighbors import KernelDensity

from sklearn.decomposition import PCA

from sklearn.model\_selection import GridSearchCV

from sklearn.mixture import GaussianMixture as GMM

from sklearn.mixture import BayesianGaussianMixture

import itertools

import matplotlib.pyplot as plt

import matplotlib as mp


def plot\_digit\_data(data):

`    `fig, ax = plt.subplots(12, 4, figsize=(8, 8),

`                           `subplot\_kw=dict(xticks=[], yticks=[]))

`    `fig.subplots\_adjust(hspace=0.05, wspace=0.05)

`    `for i, axi in enumerate(ax.flat):

`        `im = axi.imshow(data[i].reshape(8, 8), cmap='binary')

`        `im.set\_clim(0, 16)

**Kernel Density Estimation**

def kde(n):

`    `digit\_data = ld()

`    `pca = PCA(n\_components=n, whiten=False)

`    `data = pca.fit\_transform(digit\_data.data)

`    `params = {'bandwidth': np.logspace(-1, 1, 20)}

`    `grid = GridSearchCV(KernelDensity(), params, cv=5)

`    `grid.fit(data)

`    `print("bandwidth selcted : ",grid.best\_estimator\_.bandwidth )



`    `kde = grid.best\_estimator\_

`    `new\_data = kde.sample(48, random\_state=0)

`    `new\_data = pca.inverse\_transform(new\_data)

`    `print()

`    `print("48 new data points generated : ")

`    `print()

`    `plot\_digit\_data(new\_data)


**KDE for 16 features**

kde(16)


